#!/bin/bash

echo "🚀 Installation FacturX Converter..."
echo ""

# 1 — Homebrew
if ! command -v brew &>/dev/null; then
    echo "📦 Installation Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
else
    echo "✅ Homebrew déjà installé ($(brew --version | head -1))"
fi

# 2 — Java
if ! command -v java &>/dev/null; then
    echo "📦 Installation Java..."
    brew install openjdk@21
else
    echo "✅ Java déjà installé ($(java -version 2>&1 | head -1))"
fi

# 3 — Ghostscript
if ! command -v gs &>/dev/null; then
    echo "📦 Installation Ghostscript..."
    brew install ghostscript
else
    echo "✅ Ghostscript déjà installé ($(gs --version))"
fi

# 4 — Création dossier
mkdir -p /Applications/FacturX

# 5 — Copie du script
cp convertFacturX.sh /Applications/FacturX/
chmod +x /Applications/FacturX/convertFacturX.sh
echo "✅ Script convertFacturX.sh installé"

# 6 — Mustang
if [ ! -f "/Applications/FacturX/Mustang-CLI.jar" ]; then
    echo "📦 Téléchargement Mustang-CLI..."
    curl -L "https://www.mustangproject.org/deploy/Mustang-CLI-2.22.0.jar" \
         -o /Applications/FacturX/Mustang-CLI.jar
else
    echo "✅ Mustang-CLI déjà installé"
fi

echo ""
echo "✅ Installation terminée !"
echo ""
echo "👉 Voir README.md pour configurer FileMaker"
echo ""
echo "Appuie sur Entrée pour fermer..."
read