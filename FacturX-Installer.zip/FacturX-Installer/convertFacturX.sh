#!/bin/bash
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
export JAVA_HOME=$(/usr/libexec/java_home)

INPUT_PDF="$1"
INPUT_XML="$2"
OUTPUT_PDF="$3"

# Chemins des outils
GS=$(which gs)
MUSTANG="/Applications/FacturX/Mustang-CLI.jar"

# Fichier temporaire
TMP_PDFA=$(mktemp /tmp/pdfa1_XXXX.pdf)

# Étape 1 : Ghostscript → PDF/A-1b
$GS -dBATCH -dNOPAUSE -dPDFA=1 -dPDFACompatibilityPolicy=1 \
    -sDEVICE=pdfwrite \
    -sOutputFile="$TMP_PDFA" \
    "$INPUT_PDF" 2>/dev/null

# Étape 2 : Mustang → PDF/A-3b Factur-X
java -jar "$MUSTANG" -i \
     --action combine \
     --source "$TMP_PDFA" \
     --source-xml "$INPUT_XML" \
     --out "$OUTPUT_PDF" \
     --format fx \
     --version 1 \
     --profile E \
     --attachments "" 2>/dev/null

# Nettoyage
rm -f "$TMP_PDFA"

echo "OK:$OUTPUT_PDF"


